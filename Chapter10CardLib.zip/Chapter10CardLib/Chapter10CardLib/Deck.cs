﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10CardLib
{
    class Deck
    {
        private Card[] DeckOfCardInst;

        public Deck()
        {
            DeckOfCardInst = new Card[52];
            for (int suit = 1; suit <= 4; suit++)
            {
                for (int rank = 1; rank <= 13; rank++)
                {
                    DeckOfCardInst[rank + (suit - 1) * 13 - 1] = new Card((Suit)suit, (Rank)rank);
                }
            }
            /*for (int i = 0; i < 52; i++)
            {
                Console.WriteLine("{0} \n", DeckOfCardInst[i].ToString());
            }*/
        }
        public Card GetCard(int CardIndex)
        {
            Console.WriteLine("Retrived Card: {0} \n", DeckOfCardInst[CardIndex].ToString());
            return DeckOfCardInst[CardIndex];
        }
        public void Shuffle()
        {
            Card TempCard;
            int Index;
            Random SourceGen = new Random();

            for(int i= 0; i < 52; i++)
            {
                while(true)
                {
                  Index = SourceGen.Next(52);
                  for (int k = 0; k < i; k++)
                  {
                      if (DeckOfCardInst[k] == DeckOfCardInst[Index])
                      {
                          break;
                      }
                  }
                  TempCard = DeckOfCardInst[i];
                  DeckOfCardInst[i] = DeckOfCardInst[Index];
                  DeckOfCardInst[Index] = TempCard;
                  break;
                }    
            }
            for (int i = 0; i < 52; i++)
            {
                Console.WriteLine("{0} \n", DeckOfCardInst[i].ToString());
            }
        }
    }
}
