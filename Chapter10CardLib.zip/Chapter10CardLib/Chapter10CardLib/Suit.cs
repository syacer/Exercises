﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10CardLib
{
    public enum Suit
    { 
      Club = 1,
      Dimond,
      Heart,
      Spade,
    }
}
